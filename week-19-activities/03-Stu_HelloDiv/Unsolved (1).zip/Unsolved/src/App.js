import React from "react";
import HelloDiv from "./components/HelloDiv";

const App = () => <HelloDiv />;

export default App;
